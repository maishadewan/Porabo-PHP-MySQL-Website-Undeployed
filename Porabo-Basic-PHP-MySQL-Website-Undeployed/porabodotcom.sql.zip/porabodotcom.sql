-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 21, 2018 at 04:07 AM
-- Server version: 8.0.11
-- PHP Version: 7.0.30-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `porabodotcom`
--

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE `people` (
  `NID` int(5) NOT NULL,
  `Username` text NOT NULL,
  `firstName` text NOT NULL,
  `lastName` text NOT NULL,
  `MiddleName` text NOT NULL,
  `Gender` text NOT NULL,
  `Address` text NOT NULL,
  `MobilePhone` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `people`
--

INSERT INTO `people` (`NID`, `Username`, `firstName`, `lastName`, `MiddleName`, `Gender`, `Address`, `MobilePhone`) VALUES
(1234, 'Adnan', 'Adnan', 'Rasad', 'Kazi', 'MALE', 'Mirpur', '01993868240'),
(2005, 'Rasa', 'Rasa', '', 'Kazi', 'FEMALE', 'Kallanpur', ''),
(5678, 'Moumita', 'Moumita', '', 'Haque', 'FEMALE', 'Uttara', '01725719973');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `s_id` int(11) NOT NULL,
  `institution` varchar(50) NOT NULL,
  `class` int(11) NOT NULL,
  `last_class_gpa` decimal(3,2) NOT NULL,
  `rating` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`s_id`, `institution`, `class`, `last_class_gpa`, `rating`) VALUES
(2005, 'Preparatory', 6, '4.25', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `studentadvertisement`
--

CREATE TABLE `studentadvertisement` (
  `id` int(11) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `willing_to_pay` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentadvertisement`
--

INSERT INTO `studentadvertisement` (`id`, `sub`, `willing_to_pay`) VALUES
(2005, 'Programming', 5000);

-- --------------------------------------------------------

--
-- Table structure for table `tadvertisement`
--

CREATE TABLE `tadvertisement` (
  `id` int(11) NOT NULL,
  `sub` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `from_class` int(11) NOT NULL,
  `to_class` int(11) NOT NULL,
  `salary_expectation` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tadvertisement`
--

INSERT INTO `tadvertisement` (`id`, `sub`, `from_class`, `to_class`, `salary_expectation`) VALUES
(1234, 'Programming', 1, 12, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `t_id` int(11) NOT NULL,
  `school` varchar(50) NOT NULL,
  `college` varchar(50) NOT NULL,
  `university` varchar(50) NOT NULL,
  `rating` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`t_id`, `school`, `college`, `university`, `rating`) VALUES
(1234, 'DRMC', 'DRMC', 'BRAC University', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teaches`
--

CREATE TABLE `teaches` (
  `t_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `salary` int(11) NOT NULL,
  `sub` varchar(10) NOT NULL,
  `days_per_week` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `people`
--
ALTER TABLE `people`
  ADD PRIMARY KEY (`NID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`s_id`,`institution`);

--
-- Indexes for table `studentadvertisement`
--
ALTER TABLE `studentadvertisement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tadvertisement`
--
ALTER TABLE `tadvertisement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `teaches`
--
ALTER TABLE `teaches`
  ADD PRIMARY KEY (`t_id`,`s_id`),
  ADD KEY `s_id` (`s_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `people` (`nid`);

--
-- Constraints for table `studentadvertisement`
--
ALTER TABLE `studentadvertisement`
  ADD CONSTRAINT `studentadvertisement_ibfk_1` FOREIGN KEY (`id`) REFERENCES `student` (`s_id`);

--
-- Constraints for table `tadvertisement`
--
ALTER TABLE `tadvertisement`
  ADD CONSTRAINT `tadvertisement_ibfk_1` FOREIGN KEY (`id`) REFERENCES `teacher` (`t_id`);

--
-- Constraints for table `teacher`
--
ALTER TABLE `teacher`
  ADD CONSTRAINT `teacher_ibfk_1` FOREIGN KEY (`t_id`) REFERENCES `people` (`nid`);

--
-- Constraints for table `teaches`
--
ALTER TABLE `teaches`
  ADD CONSTRAINT `teaches_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `student` (`s_id`),
  ADD CONSTRAINT `teaches_ibfk_2` FOREIGN KEY (`t_id`) REFERENCES `teacher` (`t_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
